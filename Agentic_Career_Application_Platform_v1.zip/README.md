# Agentic Career Application Platform (Approval Mode)

Production-oriented starter for resume-first job discovery, semantic matching, tailored application packets, deduplication, and tracking.

## What works now
- Resume upload (PDF/DOCX/TXT) and local persistent profile text.
- Job discovery from **configured Greenhouse and Lever public job-board APIs** (no account login needed).
- Manual job URL/description intake and CSV import as optional fallback (not required).
- Matching engine with skills/title/experience/location weights and a 75% threshold.
- Optional OpenAI semantic analysis + truthful cover letter and application answers.
- SQLite deduplication and application tracking.
- Approval queue: user reviews each packet and opens the official application page to submit.
- Streamlit mobile-friendly interface.

## Platform limitations (important)
- **LinkedIn, Naukri, Indeed:** no unofficial scraping or bot login/submission is implemented. These sites restrict unauthorized automation and may use CAPTCHA/MFA. The app provides search links and supports importing job details manually, then matching and preparing the packet.
- **Apply action:** this app opens the employer/platform application URL. It does not click final Submit or bypass security checks. Submission automation requires a platform-approved API/partner integration and per-site implementation.
- Greenhouse/Lever are job discovery sources; finding a posting does not mean their apply API is open to third-party candidates.

## Setup (Windows)
1. Extract ZIP.
2. Open terminal in project folder.
3. `py -m venv .venv`
4. `.venv\\Scripts\\activate`
5. `pip install -r requirements.txt`
6. Copy `.env.example` to `.env`; optionally add `OPENAI_API_KEY`.
7. `streamlit run app.py`

## Setup (WSL/Linux)
```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
streamlit run app.py
```

## Configure public job boards
Edit `data/boards.json` and add board identifiers:
- Greenhouse: company slug (example `stripe`)
- Lever: company slug (example `canonical`)
These are public job-board APIs. Only use organizations/boards you want monitored.

## Matching
Default weighted score:
- Skills/semantic similarity: 50%
- Role/title alignment: 20%
- Experience fit: 20%
- Location fit: 10%
Threshold defaults to 75%. Score is a ranking aid, not a guarantee of qualification. Resume claims are never invented.

## Security & privacy
- Resume/profile and SQLite DB are stored on the host running Streamlit. On Streamlit Community Cloud ephemeral storage can reset; use private deployment or external persistent database/storage for production.
- Never commit `.env`, resumes, or `data/applications.db`.
- OpenAI API is optional. If enabled, selected resume/JD text is sent to OpenAI for analysis; review privacy policy and API terms before use.
- Do not store LinkedIn/Naukri/Indeed passwords in this application.

## Deployment
Streamlit Community Cloud can host the UI. For always-on discovery, configure a separate scheduler/worker (GitHub Actions, Cloud Run, or VPS) and persistent DB. The current UI runs discovery when you click **Discover jobs**; it is not a background 24/7 service.
