import re
from dataclasses import dataclass, field
@dataclass
class Profile:
    resume_text:str
    years_experience:float=9
    skills:list[str]=field(default_factory=list)
    titles:list[str]=field(default_factory=list)
    locations:list[str]=field(default_factory=list)
def extract_skills(text,skills):
    return [s for s in skills if re.search(r"(?i)"+re.escape(s),text)]
def build_profile(text,cfg):
    return Profile(text,float(cfg["candidate"].get("years_experience",9)),
      extract_skills(text,cfg["candidate"].get("skills",[])),
      cfg.get("roles",[]),cfg["candidate"].get("locations",[]))
