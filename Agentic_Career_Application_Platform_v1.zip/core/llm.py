import os,json
def enabled(): return bool(os.getenv("OPENAI_API_KEY","").strip())
def analyze(profile_text,job):
    from openai import OpenAI
    client=OpenAI(api_key=os.environ["OPENAI_API_KEY"])
    model=os.getenv("OPENAI_MODEL","gpt-4.1-mini")
    prompt=f"""Compare candidate resume and job description. Return valid JSON keys:
semantic_match (0-100), strengths (array), gaps (array), truthful_resume_summary (string),
cover_letter (string 150-220 words), application_answers (object mapping common questions
to truthful suggested answers), recommendation (string). Never invent skills, dates,
metrics, employers, certifications or accomplishments.
RESUME:
{profile_text[:18000]}
JOB:
Title: {job.get('title')}
Company: {job.get('company')}
Description: {job.get('description','')[:14000]}
"""
    r=client.chat.completions.create(model=model,temperature=0.2,
      response_format={"type":"json_object"},
      messages=[{"role":"user","content":prompt}])
    return json.loads(r.choices[0].message.content)
