import re
from difflib import SequenceMatcher
def norm(x): return re.sub(r"[^a-z0-9+#. ]"," ",str(x or "").lower())
def match(job,profile,cfg):
    jd=norm(" ".join([job.get("title",""),job.get("description",""),job.get("requirements","")]))
    skills=profile.skills
    hit=[s for s in skills if norm(s) in jd]
    skill=100*len(hit)/max(1,len(skills))
    title=norm(job.get("title",""))
    title_score=100 if any(norm(t) in title or title in norm(t) for t in profile.titles) else (
        80 if any(k in title for k in ["verification","silicon","design","staff","principal","mts","manager"]) else 45)
    exp=100
    exp_text=norm(job.get("description",""))
    m=re.search(r"(\\d+)\\s*(?:\\+\\s*)?(?:years|yrs)",exp_text)
    if m:
        req=int(m.group(1)); exp=100 if profile.years_experience>=req else max(0,100-(req-profile.years_experience)*12)
    loc=norm(job.get("location",""))
    loc_score=100 if any(norm(l) in loc for l in profile.locations) else (75 if "india" in loc or "remote" in loc else 45)
    w=cfg["matching"]["weights"]
    score=round(skill*w["skills"]+title_score*w["title"]+exp*w["experience"]+loc_score*w["location"])
    # Simple lexical fallback. OpenAI semantic score can optionally augment this.
    jd_tokens=set(jd.split()); resume_tokens=set(norm(profile.resume_text).split())
    semantic=100*len(jd_tokens&resume_tokens)/max(1,len(jd_tokens))
    return {"score":score,"skill_score":round(skill),"title_score":title_score,
      "experience_score":round(exp),"location_score":round(loc_score),
      "matched_skills":hit,"missing_skills":[s for s in skills if s not in hit],
      "lexical_similarity":round(semantic)}
