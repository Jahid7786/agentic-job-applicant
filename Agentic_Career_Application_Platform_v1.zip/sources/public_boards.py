import requests
HEADERS={"User-Agent":"CareerCopilot/1.0 (candidate job discovery; public job board API)"}
def greenhouse(slug):
    url=f"https://boards-api.greenhouse.io/v1/boards/{slug}/jobs?content=true"
    r=requests.get(url,headers=HEADERS,timeout=20); r.raise_for_status()
    out=[]
    for j in r.json().get("jobs",[]):
        out.append({"title":j.get("title",""),"company":slug,"location":j.get("location",{}).get("name",""),
          "description":j.get("content",""),"url":j.get("absolute_url",""),"source":"Greenhouse",
          "external_id":str(j.get("id",""))})
    return out
def lever(slug):
    url=f"https://api.lever.co/v0/postings/{slug}?mode=json"
    r=requests.get(url,headers=HEADERS,timeout=20); r.raise_for_status()
    out=[]
    for j in r.json():
        categories=j.get("categories",{})
        out.append({"title":j.get("text",""),"company":slug,
          "location":categories.get("location",""),"description":j.get("descriptionPlain",""),
          "requirements":j.get("lists",[]),"url":j.get("hostedUrl",""),"source":"Lever",
          "external_id":j.get("id","")})
    return out
def discover(config):
    boards=config
    alljobs=[]; errors=[]
    for slug in boards.get("greenhouse",[]):
        try: alljobs+=greenhouse(slug)
        except Exception as e: errors.append(f"Greenhouse {slug}: {e}")
    for slug in boards.get("lever",[]):
        try: alljobs+=lever(slug)
        except Exception as e: errors.append(f"Lever {slug}: {e}")
    return alljobs,errors
