from pathlib import Path
def extract(path):
    p=Path(path); ext=p.suffix.lower()
    if ext==".txt": return p.read_text(encoding="utf-8",errors="ignore")
    if ext==".pdf":
        from pypdf import PdfReader
        return "\n".join(x.extract_text() or "" for x in PdfReader(str(p)).pages)
    if ext==".docx":
        from docx import Document
        return "\n".join(x.text for x in Document(str(p)).paragraphs)
    raise ValueError("Resume must be PDF, DOCX or TXT")
