import os,json,tempfile
import streamlit as st, yaml, pandas as pd
from dotenv import load_dotenv
from utils.extract import extract
from core.profile import build_profile
from core.matcher import match
from core.llm import enabled,analyze
from sources.public_boards import discover
from storage.db import save_job,list_jobs,update_job
load_dotenv()
st.set_page_config(page_title="Agentic Career Copilot",page_icon="🎯",layout="wide")
with open("config.yaml",encoding="utf-8") as f: CFG=yaml.safe_load(f)
with open("data/boards.json",encoding="utf-8") as f: BOARDS=json.load(f)
THRESH=int(os.getenv("MATCH_THRESHOLD",CFG["matching"]["threshold"]))
st.title("🎯 Agentic Career Application Platform")
st.caption("Resume-first discovery · AI match ≥75% · application packet · approval before applying")
with st.sidebar:
 st.subheader("Agent settings")
 st.metric("Match threshold",f"{THRESH}%")
 st.write("Career levels: Senior → Staff → Principal → MTS → Manager → Director → Executive")
 st.write("AI enrichment:", "Enabled" if enabled() else "Keyword fallback (add API key for semantic analysis)")
 st.warning("Approval mode: the agent never submits an application without your review.")
tabs=st.tabs(["1 · Resume & profile","2 · Discover jobs","3 · Approval queue","4 · Tracker","5 · Job portals"])
with tabs[0]:
 st.subheader("Upload resume (once per session/profile update)")
 uploaded=st.file_uploader("Resume PDF / DOCX / TXT",type=["pdf","docx","txt"])
 if uploaded:
  with tempfile.NamedTemporaryFile(delete=False,suffix=os.path.splitext(uploaded.name)[1]) as tmp:
   tmp.write(uploaded.getvalue()); path=tmp.name
  try: text=extract(path)
  finally: os.unlink(path)
  st.session_state["resume_text"]=text
  st.session_state["resume_name"]=uploaded.name
 elif "resume_text" not in st.session_state:
  st.session_state["resume_text"]=""
 resume=st.text_area("Extracted resume text (verify/edit before matching)",st.session_state.get("resume_text",""),height=230)
 st.session_state["resume_text"]=resume
 yrs=st.number_input("Total relevant experience (years)",min_value=0.0,max_value=50.0,value=9.0,step=0.5)
 st.session_state["years"]=yrs
 locs=st.multiselect("Preferred locations",CFG["candidate"]["locations"],default=["Bengaluru","Hyderabad","Pune","India","Remote"])
 st.session_state["locations"]=locs
 st.success("Resume stays on the app host unless you enable OpenAI enrichment. If enabled, resume/JD text is sent to the configured API.")
 st.subheader("Target career levels")
 st.write(", ".join(CFG["roles"]))
with tabs[1]:
 st.subheader("Automatic discovery from configured public job boards")
 st.write("Current configured board slugs:",BOARDS)
 st.caption("Edit data/boards.json to add employers' Greenhouse/Lever board identifiers. These are public board APIs.")
 if st.button("Discover jobs now",type="primary"):
  found,errs=discover(BOARDS)
  if not found and not errs: st.warning("No boards configured. Add company slugs in data/boards.json first.")
  resume=st.session_state.get("resume_text","")
  if not resume: st.error("Upload resume first.")
  else:
   profile=build_profile(resume,CFG)
   profile.years_experience=st.session_state.get("years",9)
   profile.locations=st.session_state.get("locations",profile.locations)
   enriched=0; kept=0
   bar=st.progress(0)
   for i,j in enumerate(found):
    m=match(j,profile,CFG)
    packet={}
    if enabled():
     try:
      packet=analyze(resume,j); m["semantic_match"]=packet.get("semantic_match")
      # blended score uses AI semantic score only when successful
      m["score"]=round(.65*m["score"]+.35*float(packet["semantic_match"]))
      enriched+=1
     except Exception as e: st.warning(f"AI analysis skipped for one listing: {e}")
    j["score"]=m["score"]; j["match_json"]=json.dumps(m); j["packet_json"]=json.dumps(packet)
    j["status"]="Shortlisted" if m["score"]>=THRESH else "Below threshold"
    save_job(j)
    if j["score"]>=THRESH: kept+=1
    bar.progress((i+1)/max(1,len(found)))
   st.success(f"Processed {len(found)} postings; {kept} scored ≥{THRESH}%. AI-enriched: {enriched}.")
  for e in errs: st.warning(e)
 st.divider()
 st.subheader("Optional: add a job posting manually (not required)")
 with st.form("manualjob"):
  title=st.text_input("Title"); company=st.text_input("Company"); loc=st.text_input("Location")
  url=st.text_input("Posting URL"); desc=st.text_area("JD text")
  go=st.form_submit_button("Evaluate and queue")
 if go:
  resume=st.session_state.get("resume_text","")
  if not resume: st.error("Upload resume first.")
  else:
   p=build_profile(resume,CFG); j={"title":title,"company":company,"location":loc,"url":url,"description":desc,"source":"Manual"}
   m=match(j,p,CFG); packet={}
   if enabled():
    try:
     packet=analyze(resume,j); m["score"]=round(.65*m["score"]+.35*float(packet["semantic_match"]))
    except Exception as e: st.warning(str(e))
   j.update(score=m["score"],match_json=json.dumps(m),packet_json=json.dumps(packet),status="Shortlisted" if m["score"]>=THRESH else "Below threshold")
   save_job(j); st.success(f"Saved with match score {m['score']}%.")
with tabs[2]:
 st.subheader("Review and approve each application")
 rows=[x for x in list_jobs() if (x.get("score") or 0)>=THRESH and x.get("status") not in ["Applied","Rejected","Not suitable"]]
 if not rows: st.info("No qualifying jobs yet. Run Discover jobs.")
 for j in rows:
  with st.container(border=True):
   st.subheader(f"{j['title']} — {j['company']}")
   st.write(f"{j['location']} · {j['source']} · **{j['score']}% match**")
   m=json.loads(j.get("match_json") or "{}"); st.write("Matched skills:",", ".join(m.get("matched_skills",[])))
   packet=json.loads(j.get("packet_json") or "{}")
   if packet:
    with st.expander("AI analysis, cover letter & answers"):
     st.write("**Strengths**",packet.get("strengths",[]))
     st.write("**Gaps**",packet.get("gaps",[]))
     st.write("**Recommendation**",packet.get("recommendation",""))
     st.text_area("Tailored cover letter",packet.get("cover_letter",""),key=f"letter_{j['id']}")
     st.json(packet.get("application_answers",{}))
   if j.get("url"): st.link_button("Open official application",j["url"])
   st.warning("Review resume/letter and all application fields on the employer site. Final submission is manual.")
   c1,c2=st.columns(2)
   with c1:
    if st.button("Mark applied",key=f"applied_{j['id']}"): update_job(j["url"],"Applied"); st.rerun()
   with c2:
    if st.button("Reject / skip",key=f"skip_{j['id']}"): update_job(j["url"],"Not suitable"); st.rerun()
with tabs[3]:
 rows=list_jobs()
 if rows:
  df=pd.DataFrame(rows)
  st.dataframe(df[["title","company","location","score","source","status","url"]],use_container_width=True)
  selected=st.selectbox("Select job URL",df["url"].fillna("").tolist())
  status=st.selectbox("Update status",["Discovered","Shortlisted","Prepared","Applied","Interview","Rejected","Offer","Not suitable"])
  note=st.text_input("Notes")
  if st.button("Save tracker update"): update_job(selected,status,note); st.success("Updated")
 else: st.info("No tracked jobs yet.")
with tabs[4]:
 st.subheader("LinkedIn · Naukri · Indeed")
 st.warning("These sites do not provide a generally available public API for automated candidate applications. This app does not scrape logged-in pages or automate submit.")
 st.markdown("[LinkedIn Jobs](https://www.linkedin.com/jobs/)")
 st.markdown("[Naukri Jobs](https://www.naukri.com/)")
 st.markdown("[Indeed India](https://in.indeed.com/)")
 st.write("Use platform search or alerts; paste a suitable JD into the optional evaluator. The AI prepares your packet and you complete the application.")
 st.subheader("Company career APIs")
 st.write("Configure public Greenhouse/Lever board slugs in `data/boards.json`. Add adapters only for official/authorized APIs.")
