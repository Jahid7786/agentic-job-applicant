from types import SimpleNamespace
from core.matcher import match
def test_match_score_is_bounded():
 p=SimpleNamespace(skills=["UVM","SystemVerilog"],titles=["Senior Verification Engineer"],
  years_experience=9,locations=["Bengaluru"],resume_text="UVM SystemVerilog verification")
 cfg={"matching":{"weights":{"skills":.5,"title":.2,"experience":.2,"location":.1}}}
 j={"title":"Senior Verification Engineer","location":"Bengaluru","description":"UVM SystemVerilog 9 years"}
 r=match(j,p,cfg)
 assert 0<=r["score"]<=100
