import sqlite3,os
from pathlib import Path
DB=os.getenv("DATABASE_PATH","./data/applications.db")
def connect():
    Path(DB).parent.mkdir(parents=True,exist_ok=True)
    c=sqlite3.connect(DB); c.row_factory=sqlite3.Row
    c.execute("""CREATE TABLE IF NOT EXISTS jobs(
      id INTEGER PRIMARY KEY,title TEXT,company TEXT,location TEXT,description TEXT,url TEXT UNIQUE,
      source TEXT,external_id TEXT,score INTEGER,match_json TEXT,packet_json TEXT,
      status TEXT DEFAULT 'Discovered',notes TEXT,created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP)""")
    c.commit(); return c
def save_job(j):
    c=connect()
    c.execute("""INSERT OR IGNORE INTO jobs(title,company,location,description,url,source,external_id,score,match_json,packet_json,status)
      VALUES(?,?,?,?,?,?,?,?,?,?,?)""",(j.get("title",""),j.get("company",""),j.get("location",""),
      j.get("description",""),j.get("url",""),j.get("source",""),j.get("external_id",""),
      j.get("score",0),j.get("match_json","{}"),j.get("packet_json","{}"),j.get("status","Discovered")))
    c.commit(); c.close()
def list_jobs():
    c=connect(); rows=c.execute("SELECT * FROM jobs ORDER BY score DESC,created_at DESC").fetchall(); c.close()
    return [dict(x) for x in rows]
def update_job(url,status,notes=""):
    c=connect(); c.execute("UPDATE jobs SET status=?,notes=? WHERE url=?",(status,notes,url)); c.commit(); c.close()
