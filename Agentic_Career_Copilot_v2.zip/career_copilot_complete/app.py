import os, re, json, sqlite3, hashlib
from datetime import datetime
from pathlib import Path
import streamlit as st

APP_DIR=Path(__file__).parent
DB_PATH=APP_DIR/'career_copilot.db'

st.set_page_config(page_title='Agentic Career Copilot',page_icon='🎯',layout='wide')
st.title('🎯 Agentic Career Copilot')
st.caption('Resume-driven job matching • tailored application materials • approval-first workflow')

TARGET_TITLES=[
'Senior Verification Engineer','Senior Verification & Validation Engineer','Staff Verification Engineer','Senior Staff Engineer',
'Principal Engineer','Senior Principal Engineer','Member of Technical Staff (MTS)','Principal MTS Engineer',
'Engineering Manager','Technical Manager','Verification Manager','Project Manager','Technical Project Manager',
'Program Manager','Director of Engineering','Director of Verification','Senior Director','VP of Engineering',
'Chief Technology Officer (CTO)','Chief Executive Officer (CEO)'
]
ROLE_FAMILIES={
 'Verification / Validation':['verification','validation','design verification','dv','soc verification','ip verification','silicon validation','pre-silicon','post-silicon'],
 'SoC / IP / Silicon':['soc','system-on-chip','ip','semiconductor','silicon','asic','fpga','chip','microelectronics'],
 'Methodology / UVM':['systemverilog','uvm','testbench','verification methodology','coverage','assertion','sva','formal'],
 'Technical Leadership':['technical lead','team lead','people management','technical strategy','architecture','mentoring','cross-functional'],
 'Project / Program':['project management','program management','planning','milestone','delivery','stakeholder','budget','risk management'],
 'Executive / Business':['p&l','business strategy','organizational leadership','executive leadership','operations','business development']}

# ---------- helpers ----------
def init_db():
    with sqlite3.connect(DB_PATH) as c:
        c.execute('''CREATE TABLE IF NOT EXISTS applications(
        id INTEGER PRIMARY KEY AUTOINCREMENT, created_at TEXT, company TEXT, title TEXT, location TEXT,
        url TEXT, score INTEGER, decision TEXT, resume_version TEXT, cover_letter TEXT, notes TEXT)''')
init_db()

def extract_resume(upload):
    if upload is None: return ''
    name=upload.name.lower(); data=upload.getvalue()
    try:
        if name.endswith('.txt'): return data.decode('utf-8',errors='ignore')
        if name.endswith('.pdf'):
            from pypdf import PdfReader
            import io
            reader=PdfReader(io.BytesIO(data)); return '\n'.join(p.extract_text() or '' for p in reader.pages)
        if name.endswith('.docx'):
            from docx import Document
            import io
            doc=Document(io.BytesIO(data)); return '\n'.join(p.text for p in doc.paragraphs)
    except Exception as e: st.error(f'Resume extraction error: {e}')
    return ''

def words(text): return set(re.findall(r'[a-zA-Z][a-zA-Z0-9+#./-]{1,}',(text or '').lower()))

def score_job(resume, jd, title, experience_years=9):
    r=(resume or '').lower(); j=((title or '')+' '+(jd or '')).lower()
    skills=['systemverilog','sv','uvm','soc','ip verification','design verification','verification','validation',
            'coverage','sva','assertion','axi','ahb','apb','pcie','i2c','spi','mipi','usb','noc','dma',
            'debug','testbench','scoreboard','sequence','semiconductor','silicon','asic','rtl','python','perl',
            'tcl','linux','vcs','questa','verdi','formal','gls','upf','functional coverage','regression']
    resume_hits=[s for s in skills if s in r]
    jd_hits=[s for s in skills if s in j]
    overlap=[s for s in jd_hits if s in r]
    skill_score= 100*len(overlap)/max(1,len(jd_hits))
    # lexical similarity as supplementary signal
    rw=words(r); jw=words(j)
    meaningful={w for w in jw if len(w)>3 and w not in {'with','from','this','that','will','have','your','team','role','work','years','required','preferred','about','into','their','they','such','which','what','more','must','also','responsibilities','experience','skills','engineer','engineering'}}
    lexical=100*len(rw & meaningful)/max(1,len(meaningful))
    title_bonus=10 if any(x in r for x in ['lead','manager','mentor','architect','technical leadership']) and any(x in title.lower() for x in ['manager','lead','director','principal','staff']) else 0
    exp_text=' '.join(re.findall(r'\d+\s*\+?\s*(?:years|yrs)',j))
    exp_penalty=0
    nums=[int(x) for x in re.findall(r'(\d+)\s*\+?\s*(?:years|yrs)',exp_text)]
    if nums and max(nums)>experience_years+2: exp_penalty=15
    score=int(max(0,min(100,0.75*skill_score+0.25*lexical+title_bonus-exp_penalty)))
    return score,overlap,jd_hits

def make_cover_letter(name, resume, title, company, jd, api_key=''):
    if api_key:
        try:
            from openai import OpenAI
            client=OpenAI(api_key=api_key)
            prompt=f'''Write a concise, truthful, tailored cover letter. Do not invent qualifications. Candidate resume:
{resume[:10000]}
Role: {title} at {company}
Job description:
{jd[:8000]}
Highlight relevant overlap and express interest. 250 words max.'''
            resp=client.chat.completions.create(model='gpt-4o-mini',messages=[{'role':'user','content':prompt}],temperature=.3)
            return resp.choices[0].message.content.strip()
        except Exception as e: return f'AI generation failed ({e}). Please draft manually from the resume and JD.'
    # deterministic starter when no API configured
    return (f'Dear Hiring Team,\n\nI am interested in the {title} opportunity at {company}. '
            'My background includes semiconductor design verification and validation, SystemVerilog/UVM testbench development, '
            'debug, coverage closure, and collaboration across design and verification teams. '
            'I would welcome the opportunity to discuss how my experience aligns with your team’s needs.\n\n'
            'Please review and personalize this draft against the exact job description before submitting.\n\nSincerely,\n'+(name or 'Candidate'))

# ---------- sidebar profile ----------
st.sidebar.header('Candidate profile')
name=st.sidebar.text_input('Full name',value='Jahid Khan')
experience=st.sidebar.slider('Years of experience',min_value=1,max_value=25,value=9)
minimum=st.sidebar.slider('Minimum match score (%)',min_value=50,max_value=100,value=75,step=5)
api_key=st.sidebar.text_input('OpenAI API key (optional)',type='password',help='Used only to generate tailored cover letters. Not required for matching.')
st.sidebar.caption('Career targets: Senior / Staff / Principal / Senior Principal / MTS / Technical & Engineering Manager / Project & Program Manager / Director / Senior Director / VP / CTO / CEO (domain and scope must fit).')

# ---------- resume ----------
st.header('1. Your resume and profile')
resume_file=st.file_uploader('Upload your latest resume',type=['pdf','docx','txt'])
resume_text=extract_resume(resume_file)
profile_text=st.text_area('Add or correct profile details (skills, leadership, projects, tools, achievements)',height=150,
                         placeholder='Example: 9 years semiconductor experience; 7.9 years SoC/IP DV; SystemVerilog, UVM, PCIe, AXI; verification ownership, mentoring, debug...')
combined_resume=(resume_text+'\n'+profile_text).strip()
if resume_text: st.success(f'Resume text extracted ({len(resume_text)} characters). Please verify extraction and add missing details above.')

st.header('2. Add opportunities — no CSV required')
st.info('Paste a job description or add a job URL/title. For reliable analysis, include the complete JD text. LinkedIn pages may require sign-in; this app does not scrape LinkedIn or bypass access controls.')
with st.form('job_form'):
    c1,c2=st.columns(2)
    job_title=c1.text_input('Job title*',placeholder='Principal Engineer – SoC Verification')
    company=c2.text_input('Company*',placeholder='Company name')
    location=st.text_input('Location / work mode',placeholder='Bengaluru / Hyderabad / Remote')
    job_url=st.text_input('Job posting URL',placeholder='https://www.linkedin.com/jobs/view/...')
    jd=st.text_area('Complete job description (recommended)*',height=230,placeholder='Paste responsibilities, required/preferred skills, qualifications, experience, leadership expectations...')
    submitted=st.form_submit_button('Analyze match',type='primary',use_container_width=True)

if submitted:
    if not combined_resume: st.error('Upload a resume or add profile details first.')
    elif not job_title or not company or not jd: st.error('Please provide job title, company, and job description for a meaningful match.')
    else:
        score,overlap,jd_skills=score_job(combined_resume,jd,job_title,experience)
        st.session_state['latest_job']={'title':job_title,'company':company,'location':location,'url':job_url,'jd':jd,'score':score,'overlap':overlap,'jd_skills':jd_skills}

job=st.session_state.get('latest_job')
if job:
    st.header('3. Match analysis')
    col1,col2,col3=st.columns(3)
    col1.metric('Profile match',f"{job['score']}%",delta='Meets threshold' if job['score']>=minimum else 'Below threshold')
    col2.metric('Matched skills',len(job['overlap']))
    col3.metric('JD skill signals',len(job['jd_skills']))
    st.progress(job['score']/100)
    st.write('**Matched skills:** '+(', '.join(job['overlap']) if job['overlap'] else 'No direct skill overlap found; inspect JD and resume manually.'))
    st.write('**JD skill terms detected:** '+(', '.join(job['jd_skills']) if job['jd_skills'] else 'No configured skill terms detected.'))
    if job['score']<minimum: st.warning(f"Score is below your {minimum}% threshold. You can still review it, but it won't be marked as a priority match.")
    st.header('4. Tailor application materials')
    st.caption('Generated content must be reviewed. The app does not add false skills, employers, certifications, or achievements.')
    if st.button('Draft tailored cover letter',disabled=not combined_resume):
        st.session_state['cover']=make_cover_letter(name,combined_resume,job['title'],job['company'],job['jd'],api_key)
    cover=st.text_area('Cover letter — editable',value=st.session_state.get('cover',''),height=220,key='cover_editor')
    # Store current edited text for action
    st.session_state['cover_current']=cover
    st.header('5. Review and approve application')
    st.write('**Application package**')
    st.write(f"- Position: {job['title']}\n- Company: {job['company']}\n- Location: {job['location'] or 'Not specified'}\n- Match score: {job['score']}%\n- Resume: {resume_file.name if resume_file else 'Profile text only'}\n- Cover letter: {'Drafted' if cover.strip() else 'Not drafted'}")
    approve=st.checkbox('I reviewed the job details and materials. Save this as approved for me to submit through the employer’s permitted application flow.')
    if st.button('Save to application tracker',type='primary'):
        decision='Approved for user submission' if approve else 'Saved — pending review'
        with sqlite3.connect(DB_PATH) as c:
            c.execute('INSERT INTO applications(created_at,company,title,location,url,score,decision,resume_version,cover_letter,notes) VALUES(?,?,?,?,?,?,?,?,?,?)',
            (datetime.now().isoformat(timespec='seconds'),job['company'],job['title'],job['location'],job['url'],job['score'],decision,
             resume_file.name if resume_file else 'profile text',st.session_state.get('cover_current',''),'User must submit via permitted official flow'))
        st.success('Saved in tracker.')

st.header('6. Application tracker')
with sqlite3.connect(DB_PATH) as c:
    rows=c.execute('SELECT id,created_at,company,title,location,url,score,decision FROM applications ORDER BY id DESC').fetchall()
if rows:
    st.dataframe([{'ID':r[0],'Date':r[1],'Company':r[2],'Title':r[3],'Location':r[4],'URL':r[5],'Match %':r[6],'Status':r[7]} for r in rows],use_container_width=True,hide_index=True)
    ids=[r[0] for r in rows]
    selected=st.selectbox('Update status for application ID',ids)
    new_status=st.selectbox('Status',['Saved — pending review','Approved for user submission','Applied by user','Recruiter contacted','Interview','Rejected','Offer','Withdrawn'])
    if st.button('Update status'):
        with sqlite3.connect(DB_PATH) as c: c.execute('UPDATE applications SET decision=? WHERE id=?',(new_status,selected))
        st.rerun()
else: st.caption('No applications tracked yet. Analyze a job and save it above.')

st.divider()
st.caption('Safety & accuracy: This app assists with discovery, matching, drafting, and tracking. It does not automatically submit applications, scrape behind login, or store LinkedIn credentials. Review every application and use official/authorized application mechanisms.')
