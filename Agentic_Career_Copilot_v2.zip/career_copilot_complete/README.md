# Agentic Career Copilot

Mobile-friendly Streamlit application to analyze a resume, compare it with job descriptions, draft truthful tailored cover letters, and track applications.

## Included
- Resume text extraction: PDF, DOCX, TXT
- Manual JD entry (no CSV required)
- Skill/keyword overlap and lexical match score
- 75% default threshold (adjustable)
- Career targets from Senior/Staff/Principal/MTS through technical/project leadership and executive roles
- Optional OpenAI API key for cover-letter drafting
- Approval checkbox and application tracker backed by SQLite

## Run locally
```bash
python -m venv .venv
# Windows: .venv\\Scripts\\activate
# macOS/Linux: source .venv/bin/activate
pip install -r requirements.txt
streamlit run app.py
```

## Deploy to Streamlit Community Cloud
1. Upload/commit `app.py`, `requirements.txt`, `config.yaml`, `.streamlit/config.toml` to the repository root.
2. In Streamlit Cloud set Main file path to `app.py` and branch to your repository branch (e.g. `main`).
3. Commit updates trigger app rebuild/reboot.

## Optional OpenAI API key
Enter your key in the app's sidebar to generate a tailored cover letter. It is used for that generation call. Do not commit API keys to GitHub.

## LinkedIn and applications
This project does not scrape LinkedIn, bypass login, or automate submissions. LinkedIn restricts unauthorized bots and scraping. Use official APIs, authorized partner integrations, or the employer's permitted application flow. The app supports approval and tracking, not unattended mass application.

## Matching note
The match score is a transparent heuristic based on configured technical terms and lexical overlap, not a hiring probability. Always review the full JD, eligibility, location, seniority, and resume accuracy.
