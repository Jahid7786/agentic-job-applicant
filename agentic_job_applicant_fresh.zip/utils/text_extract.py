from pathlib import Path
def extract_resume(path):
    p=Path(path)
    if p.suffix.lower()==".txt": return p.read_text(encoding="utf-8",errors="ignore")
    if p.suffix.lower()==".pdf":
        from pypdf import PdfReader
        return "\n".join(page.extract_text() or "" for page in PdfReader(str(p)).pages)
    if p.suffix.lower()==".docx":
        from docx import Document
        return "\n".join(x.text for x in Document(str(p)).paragraphs)
    raise ValueError("Use PDF, DOCX, or TXT")
