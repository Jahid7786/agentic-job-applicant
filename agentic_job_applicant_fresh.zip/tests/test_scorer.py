from types import SimpleNamespace
from agent.scorer import score_job
def test_score():
    p=SimpleNamespace(skills=["SystemVerilog","UVM","PCIe"],
      target_titles=["Senior Design Verification Engineer"],years_experience=9,locations=["Bengaluru"])
    j={"title":"Senior Design Verification Engineer","location":"Bengaluru",
       "description":"9 years SystemVerilog UVM PCIe verification"}
    assert score_job(j,p).score >= 75
