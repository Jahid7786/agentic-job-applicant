def build_prompt(resume_text, job):
    return f"""Tailor this resume truthfully to this job. Do not invent employers, dates, skills,
metrics, or accomplishments. Flag gaps explicitly.
RESUME: {resume_text}
JOB: {job.get('title','')} {job.get('description','')}
"""
