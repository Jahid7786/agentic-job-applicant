from agent.scorer import score_job

class JobAgent:
    def __init__(self, profile, min_score=75):
        self.profile, self.min_score = profile, min_score
    def evaluate(self, jobs):
        result = []
        for job in jobs:
            item = dict(job)
            item["match"] = score_job(item, self.profile, self.min_score)
            item["eligible"] = item["match"].score >= self.min_score
            result.append(item)
        return sorted(result, key=lambda j: j["match"].score, reverse=True)
    def shortlist(self, jobs):
        return [j for j in self.evaluate(jobs) if j["eligible"]]
