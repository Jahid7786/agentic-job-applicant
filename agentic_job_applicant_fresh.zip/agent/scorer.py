import re
from dataclasses import dataclass

@dataclass
class MatchResult:
    score: int
    skill_score: float
    title_score: float
    experience_score: float
    location_score: float
    matched_skills: list
    missing_skills: list
    explanation: str

def norm(s):
    return re.sub(r"[^a-z0-9+#. ]", " ", str(s or "").lower())

def score_job(job, profile, min_score=75):
    text = norm(" ".join([job.get("title",""), job.get("description",""), job.get("requirements","")]))
    skills = list(dict.fromkeys(profile.skills))
    matched = [s for s in skills if norm(s) in text]
    missing = [s for s in skills if s not in matched]
    skill = 100 * len(matched) / max(1, len(skills))
    title = norm(job.get("title",""))
    targets = [norm(t) for t in profile.target_titles]
    title_score = 100 if any(t and (t in title or title in t) for t in targets) else (
        70 if any(x in title for x in ["verification engineer","dv engineer","design verification"]) else 30)
    exp_min, exp_max = job.get("experience_min"), job.get("experience_max")
    yrs = profile.years_experience
    if exp_min != "" and exp_max != "" and exp_min is not None and exp_max is not None:
        try:
            exp_min, exp_max = float(exp_min), float(exp_max)
            exp_score = 100 if exp_min <= yrs <= exp_max else max(0, 100-20*min(abs(yrs-exp_min),abs(yrs-exp_max)))
        except (ValueError, TypeError):
            exp_score = 75
    else:
        exp_score = 100 if re.search(r"\b(7|8|9|10)\s*\+?\s*(years|yrs)", text) else 75
    loc = norm(job.get("location",""))
    loc_score = 100 if any(norm(x) in loc for x in profile.locations) else (70 if "india" in loc or "remote" in loc else 40)
    total = round(.50*skill + .20*title_score + .20*exp_score + .10*loc_score)
    explain = f"Skills {skill:.0f}% · Title {title_score:.0f}% · Experience {exp_score:.0f}% · Location {loc_score:.0f}%"
    return MatchResult(total, skill, title_score, exp_score, loc_score, matched, missing, explain)
