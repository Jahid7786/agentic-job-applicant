from dataclasses import dataclass, field
import re

@dataclass
class CandidateProfile:
    years_experience: float = 9.0
    target_titles: list = field(default_factory=list)
    skills: list = field(default_factory=list)
    locations: list = field(default_factory=list)
    resume_text: str = ""

    @classmethod
    def from_text(cls, text, config):
        cfg = config.get("agent", {})
        skills = cfg.get("core_skills", [])
        verified = [s for s in skills if re.search(re.escape(s), text, re.I)]
        return cls(9.0, cfg.get("target_titles", []), verified,
                   cfg.get("locations", []), text)
