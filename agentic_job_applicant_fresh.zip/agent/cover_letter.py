def build_prompt(profile_text, job):
    return f"""Write a concise, truthful cover letter using only verified candidate details.
Candidate: {profile_text}
Job: {job.get('title','')} at {job.get('company','')}
Description: {job.get('description','')}
"""
