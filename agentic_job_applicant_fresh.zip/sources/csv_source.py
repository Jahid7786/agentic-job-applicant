import pandas as pd
class CSVJobSource:
    def fetch(self, path):
        return pd.read_csv(path).fillna("").to_dict("records")
