"""Opens a job page for user review; does not submit applications or bypass controls."""
from playwright.sync_api import sync_playwright
def open_job_for_review(url):
    with sync_playwright() as p:
        browser = p.chromium.launch(headless=False)
        page = browser.new_page()
        page.goto(url, wait_until="domcontentloaded")
        input("Review the page yourself. Press Enter to close.")
        browser.close()
if __name__ == "__main__":
    import sys
    if len(sys.argv) > 1: open_job_for_review(sys.argv[1])
    else: print("Usage: python -m browser.assisted_browser <job-url>")
