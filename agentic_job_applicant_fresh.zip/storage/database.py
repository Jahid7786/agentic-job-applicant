import sqlite3, os
from pathlib import Path
DB = os.getenv("DATABASE_PATH", "./data/applications.db")
def connect(path=DB):
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    c=sqlite3.connect(path); c.row_factory=sqlite3.Row
    c.execute("""CREATE TABLE IF NOT EXISTS jobs(
    id INTEGER PRIMARY KEY, title TEXT, company TEXT, location TEXT, description TEXT,
    url TEXT UNIQUE, source TEXT, score INTEGER, status TEXT DEFAULT 'Shortlisted',
    notes TEXT, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP)""")
    c.commit(); return c
def upsert_job(j, path=DB):
    c=connect(path)
    c.execute("""INSERT INTO jobs(title,company,location,description,url,source,score,status,notes)
    VALUES(?,?,?,?,?,?,?,?,?) ON CONFLICT(url) DO UPDATE SET score=excluded.score""",
    (j.get("title",""),j.get("company",""),j.get("location",""),j.get("description",""),
     j.get("url",""),j.get("source",""),j.get("match").score if j.get("match") else j.get("score",0),
     j.get("status","Shortlisted"),j.get("notes","")))
    c.commit(); c.close()
def all_jobs(path=DB):
    c=connect(path); rows=c.execute("SELECT * FROM jobs ORDER BY score DESC,created_at DESC").fetchall()
    c.close(); return [dict(x) for x in rows]
def update_status(url,status,notes="",path=DB):
    c=connect(path); c.execute("UPDATE jobs SET status=?,notes=? WHERE url=?",(status,notes,url))
    c.commit(); c.close()
